---
name: seedance-master
description: >-
  Master skill for generating Seedance 2.0 video prompts on Higgsfield AND actually
  running them. Routes any video request to the right genre module (cinematic, 3D/CGI,
  fight, anime, cartoon, comic-to-video, music video, brand story, social hook,
  product 360, e-commerce ad, motion-design ad, fashion lookbook, food & beverage,
  real estate) and adds the missing execution layer: Higgsfield CLI/MCP generation,
  image-to-video with a start frame, resolution/duration/cost, prompt de-sensitization,
  and render waiting. Use whenever the user wants a Seedance / Higgsfield AI video,
  an image-to-video clip, a cinematic/CGI/animated/product/ad video prompt, or wants
  to animate a still image. Triggers: seedance, higgsfield, image to video, i2v,
  animate this image, cinematic video, 3d render video, fly-through, camera move,
  video prompt, ai video.
---

# Seedance 2.0 Master — Prompt + Generation

One entry point for everything Seedance 2.0 on Higgsfield: **write the right prompt**
(15 genre engines) **and run it** (Higgsfield CLI/MCP). The 15 genre files in
`references/` are prompt-writing guides; this master adds the execution layer they lack.

---

## Step 1 — Route to the genre module

Pick the closest genre from the request, then **read the matching file in `references/`
for its full template, camera/lighting/color libraries, and examples.** When in doubt
between two, read both and blend. The genre files are deep (~1000+ lines each) — open
the one you need on demand, don't reproduce them from memory.

| Request is about… | Read `references/` |
|---|---|
| Film-like, dramatic, movie quality, "cinematic", Hollywood, depth of field, lens flare | `genre-cinematic.md` |
| 3D render, CGI, Pixar/Unreal look, rendered surfaces, stylized 3D | `genre-3d-cgi.md` |
| Combat, action, martial arts, fight choreography | `genre-fight-scenes.md` |
| Anime / Japanese animation, shonen/seinen | `genre-anime-action.md` |
| Cartoon, 2D animation, cel-shaded | `genre-cartoon.md` |
| Animating comic / manga / webtoon / storyboard panels | `genre-comic-to-video.md` |
| Music video, beat-synced, lyric visuals | `genre-music-video.md` |
| Brand storytelling / narrative brand film | `genre-brand-story.md` |
| Viral hook for TikTok / Reels / Shorts | `genre-social-hook.md` |
| Product 360 / turntable / multi-angle reveal | `genre-product-360.md` |
| E-commerce product ad | `genre-ecommerce-ad.md` |
| SaaS / tech / motion-design ad | `genre-motion-design-ad.md` |
| Fashion lookbook / model showcase | `genre-fashion-lookbook.md` |
| Food & beverage / recipe / restaurant | `genre-food-beverage.md` |
| Real estate / architecture / interior tour | `genre-real-estate.md` |

If the brief is an immersive abstract / installation / "world" piece (e.g. a glowing
tunnel, light environment), use **`genre-cinematic.md`** as the base and blend
**`genre-3d-cgi.md`** for the rendered-surface look.

---

## Step 2 — Build the prompt (shared core)

All genres share this backbone. Use the genre file for the deep libraries.

**Master prompt template (block structure):**
```
[ESTABLISHING]  location/subject, scale, atmosphere, the focal point
[CAMERA + PRIMARY ACTION]  camera move (from the Camera Encyclopedia) + main action
[LIVING SPACE / SUBJECT MOTION]  what moves besides the camera (describe each element)
[PEOPLE]  kinetic action verbs ("walk forward, step by step"), not "stand"
[CAMERA SPECS]  lens (mm), height/angle, depth of field (f-stop), speed, focus
[LIGHTING]  key/fill/back, color temperature (Kelvin), volumetric/god-rays
[COLOR GRADE]  named grade + "do not drift to X" guardrails
[PACING + MOOD]  speed of motion + emotional target
[OUTPUT]  aspect ratio, duration, render style
```

**Rules that matter:**
- **Image-to-video: do NOT re-describe the still.** The start frame already holds the
  look. Describe only **motion, camera, lighting shift, mood**. Re-describing causes
  identity/background drift.
- **Camera is the lead component.** Always specify type + lens + angle/height + move +
  speed. Pull exact phrasing from the genre file's Camera Encyclopedia (Dolly Forward,
  Steadicam, Crane, Push-In, Parallax, Orbit, etc.).
- **Animate the space, not just the camera.** Give explicit motion verbs to walls,
  particles, light, the focal core — otherwise the scene reads dead ("only the camera
  moves").
- **People must act.** Use kinetic verbs; static figures read lifeless.
- **Lock color with guardrails.** Name the grade AND add "do not drift to plain blue /
  do not desaturate" so the model doesn't wash it out.
- **Length:** the genre engines are built for **detailed, production-grade block
  prompts** (camera in ft/s, lens mm, f-stop, Kelvin). That detail is intentional and
  beats the generic "≤80 words" advice for cinematic/CGI work. For simple single-action
  clips, shorter is fine.

---

## Step 3 — De-sensitize before sending (avoid moderation)

Higgsfield/Seedance moderation can silently fail a job (it just doesn't appear, or
returns no `result_url`). Common triggers and safe swaps:

| Risky term | Safe swap |
|---|---|
| tissue, flesh, vein, vascular, organ, body interior, anatomy | organic walls / glowing filaments / membranes / channels |
| blood, gore, wound | (remove) / warm light / red glow |
| beats like a heart | pulses slowly and rhythmically |
| named real people, brands, logos | generic / original / unbranded |

For image-to-video the look is already in the start frame, so you can describe motion
in fully neutral terms and still get the "organic/body" feel from the image.

---

## Step 4 — Generate on Higgsfield (the part the genre files omit)

Bootstrap: if `higgsfield` is not on PATH → `curl -fsSL https://raw.githubusercontent.com/higgsfield-ai/cli/main/install.sh | sh`.
If `higgsfield account status` fails → ask the user to run `higgsfield auth login`.

**Seedance 2.0 constraints:** resolution `480p|720p|1080p` (1080p = max), duration `4–15s`,
aspect `auto|21:9|16:9|4:3|1:1|3:4|9:16`, media roles `image|start_image|end_image|video|audio`.

**Preflight cost (free):**
```bash
higgsfield generate cost seedance_2_0 --resolution 1080p --duration 5
```
Rough Seedance i2v cost: ~22 cr (720p/5s) · ~45 cr (1080p/5s). Always confirm spend
with the user first if they are cost-conscious.

**Image-to-video (animate a still) — the main workflow:**
```bash
higgsfield generate create seedance_2_0 \
  --start-image "C:/path/to/frame.png" \
  --prompt "<block prompt>" \
  --resolution 1080p --duration 5 --aspect_ratio 16:9 \
  --wait --wait-timeout 15m --json
```
- `--start-image` auto-uploads the local file and anchors the first frame.
- `--wait` blocks and prints the final job JSON (with `result_url`).
- Capture the URL: `... --json 2>&1 | grep -oE '"result_url": *"[^"]*"' | head -1`.

**If no `result_url` comes back:** the job likely failed moderation or transiently.
Check `higgsfield generate list --json` — if the new job isn't at the top, it didn't
complete. Re-run; if it keeps failing, de-sensitize the prompt (Step 3). There is **no
cancel** command, and submitted jobs are charged.

**Long renders:** run with `run_in_background` and let the completion notification wake
you; don't poll in a loop.

---

## Step 5 — Deliver & QA

- Download the mp4, extract a few frames (start / mid / end with ffmpeg `-ss`) to verify
  the **camera actually travelled** (composition changes) and the **scene is alive**
  (walls/particles/light/people moved), since a single frame can't show motion.
- Give the user the result URL + a one-line summary (model, duration, what to look for).
- If motion/people/pulse are weak, strengthen those specific lines in the same block
  prompt and re-run — don't rewrite from scratch.

---

## Notes / lessons baked in

- Seedance **travels forward** well (good for fly-throughs/descents); Kling tends to
  "animate in place" — prefer Seedance for camera-travel shots.
- For sharper source than 720p text-to-video: generate/upscale the **still** first
  (Seedream 4.5 / GPT Image 2 / Nano Banana Pro), grade it, then animate via i2v.
- Post-grade and a CSS/canvas micro-pulse are good **backups** to lock color and add
  breathing independently of the model.
